import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class CarouselWithIndicatorPage extends StatefulWidget {
  @override
  _CarouselWithIndicatorPageState createState() => _CarouselWithIndicatorPageState();
}

class _CarouselWithIndicatorPageState extends State<CarouselWithIndicatorPage> {
  int _currentIndex = 0;
  final CarouselController _carouselController = CarouselController();

  // List of images and corresponding texts
  final List<String> _carouselImages = [
    'assets/images/image1.jpg',
    // 'assets/images/background.jpg',
    'assets/images/image3.jpg',
  ];

  final List<String> _carouselTexts = [
    'This is the description for Image 1.',
    'This is the description for Image 2.',
    'This is the description for Image 3.',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Carousel Slider with Text"),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Carousel Slider
          CarouselSlider.builder(
            itemCount: _carouselImages.length,
            // carouselController: _carouselController,
            options: CarouselOptions(
              height: 220,
              enlargeCenterPage: true,
              autoPlay: true,
              onPageChanged: (index, reason) {
                setState(() {
                  _currentIndex = index;
                });
              },
            ),
            itemBuilder: (context, index, realIndex) {
              return Column(
                children: [
                  // Display image
                  Image.asset(
                    _carouselImages[index],
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: 150,
                  ),
                  SizedBox(height: 10),
                  // Display text below each image
                  Text(
                    _carouselTexts[index],
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                    textAlign: TextAlign.center,
                  ),
                ],
              );
            },
          ),

          // Smooth Page Indicator
          SizedBox(height: 10),
          AnimatedSmoothIndicator(
            activeIndex: _currentIndex,
            count: _carouselImages.length,
            effect: WormEffect(
              dotHeight: 10,
              dotWidth: 10,
              activeDotColor: Colors.blue,
              dotColor: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
}